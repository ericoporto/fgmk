# fgmkBlankProject
A blank game project
